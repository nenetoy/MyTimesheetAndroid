# Attendance Tracker Android

Final APK project for the Attendance Tracker.

## Build with Codemagic
1. Upload this project to GitHub (or import the ZIP contents into a repository).
2. Connect the repository to Codemagic.
3. Use `codemagic.yaml` workflow: **Attendance Tracker Debug APK**.
4. Download `app-debug.apk` from build artifacts.

## Owner tools
Hidden owner access is kept on the Android native side.

## Data
Attendance records and profile are stored locally in WebView localStorage on each phone.
