# Attendance Tracker Android

Firebase-enabled employee attendance application.

Features:
- Native 2.5-second splash screen
- Attendance Tracker / by Billy / PEC branding
- First-use employee profile registration
- Name, position, and manually entered Employee ID
- Local-first Travel In / Duty In / Duty Out / Travel Out
- Firebase anonymous authentication
- Firestore profile and attendance synchronization
- Synced / pending / offline cloud status
- Monthly Word export
- Screenshot and screen-recording protection
- Hidden owner tools retained

Firebase project: traxer-650ff
