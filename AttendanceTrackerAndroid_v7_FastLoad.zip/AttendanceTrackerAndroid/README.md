# Attendance Tracker Android

Firebase-enabled employee attendance application.

Version 2.2.0

Features:
- Native splash screen: Attendance Tracker / by Billy / PEC
- First-use employee registration
- Name, position, and manually entered Employee ID
- Local-first Travel In / Duty In / Duty Out / Travel Out
- Firebase anonymous authentication
- Firestore profile and attendance synchronization
- Synced / pending / offline cloud status
- Reset current session only:
  - current day's active row is marked Reset
  - old cloud record is preserved
  - note is saved as "Reset by user"
  - a new punch on the same day creates a new row/session
  - previous dates are not changed
- Monthly Word export
- Screenshot and screen-recording protection
- Hidden owner tools retained

Firebase project: traxer-650ff

UI terminology: Travel Start → Duty In → Duty Out → Travel Stop
